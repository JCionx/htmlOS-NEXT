import { Button } from "./button";
import { cn } from "@/lib/utils";

interface PaginationProps {
  currentPage: number;
  totalPages?: number; // Optional if we don't know the total
  onPageChange: (page: number) => void;
  className?: string;
  hasNextPage?: boolean;
}

export function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  className,
  hasNextPage,
}: PaginationProps) {
  return (
    <div
      className={cn("flex items-center justify-center gap-2 py-4", className)}
    >
      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(Math.max(0, currentPage - 1))}
        disabled={currentPage === 0}
      >
        Previous
      </Button>

      <div className="flex items-center gap-1 text-sm font-medium">
        <span>Page {currentPage + 1}</span>
        {totalPages && <span> of {totalPages}</span>}
      </div>

      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={totalPages ? currentPage >= totalPages - 1 : !hasNextPage}
      >
        Next
      </Button>
    </div>
  );
}
