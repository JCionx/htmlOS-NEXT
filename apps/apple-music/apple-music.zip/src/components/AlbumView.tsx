import AlbumItem from "./AlbumItem";
import { Pagination } from "./ui/pagination";

interface AlbumViewProps {
  musicKitLoaded: boolean;
  loadingAlbums: boolean;
  albums: any[];
  onAlbumClick: (album: any) => void;
  page: number;
  setPage: (page: number) => void;
}

function AlbumView({
  musicKitLoaded,
  loadingAlbums,
  albums,
  onAlbumClick,
  page,
  setPage,
}: AlbumViewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* only show playlists mapping after MusicKit is initialized */}
      {!musicKitLoaded && (
        <div className="p-4 text-center">Waiting for MusicKit...</div>
      )}
      {musicKitLoaded && loadingAlbums && (
        <div className="p-4 text-center">Loading albums...</div>
      )}
      {musicKitLoaded && albums && (
        <>
          <div className="flex-1 overflow-y-auto">
            {albums.map((pl: any) => (
              <AlbumItem
                key={pl.id}
                album={pl}
                onClick={() => onAlbumClick(pl)}
              />
            ))}
          </div>
          <Pagination
            currentPage={page / 50}
            onPageChange={(newPage) => setPage(newPage * 50)}
            hasNextPage={albums.length === 50}
            className="mt-auto border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
          />
        </>
      )}
    </div>
  );
}

export default AlbumView;
