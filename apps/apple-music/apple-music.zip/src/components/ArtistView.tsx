import ArtistItem from "./ArtistItem";
import { Pagination } from "./ui/pagination";

interface ArtistViewProps {
  musicKitLoaded: boolean;
  loadingArtists: boolean;
  artists: any[];
  onArtistClick: (artist: any) => void;
  page: number;
  setPage: (page: number) => void;
}

function ArtistView({
  musicKitLoaded,
  loadingArtists,
  artists,
  onArtistClick,
  page,
  setPage,
}: ArtistViewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* only show playlists mapping after MusicKit is initialized */}
      {!musicKitLoaded && (
        <div className="p-4 text-center">Waiting for MusicKit...</div>
      )}
      {musicKitLoaded && loadingArtists && (
        <div className="p-4 text-center">Loading artists...</div>
      )}
      {musicKitLoaded && artists && (
        <>
          <div className="flex-1 overflow-y-auto">
            {artists.map((pl: any) => (
              <ArtistItem
                key={pl.id}
                artist={pl}
                onClick={() => onArtistClick(pl)}
              />
            ))}
          </div>
          <Pagination
            currentPage={page / 50}
            onPageChange={(newPage) => setPage(newPage * 50)}
            hasNextPage={artists.length === 50}
            className="mt-auto border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
          />
        </>
      )}
    </div>
  );
}

export default ArtistView;
