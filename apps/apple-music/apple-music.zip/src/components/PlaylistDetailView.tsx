import { useEffect, useState } from "react";
import SongItem from "./SongItem";
import { Button } from "./ui/button";

interface PlaylistDetailViewProps {
  playlist: any;
  musicInstance: any;
  playSong?: (id: string) => void;
  nowPlaying?: any;
}

function PlaylistDetailView({
  playlist,
  musicInstance,
  nowPlaying,
}: PlaylistDetailViewProps) {
  const [tracks, setTracks] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!musicInstance || !playlist) return;

    const fetchTracks = async () => {
      setLoading(true);
      try {
        const res = await musicInstance.api.music(
          `v1/me/library/playlists/${playlist.id}/tracks`
        );
        setTracks(res.data.data || []);
      } catch (e) {
        console.error("Failed to fetch playlist tracks", e);
      } finally {
        setLoading(false);
      }
    };

    fetchTracks();
  }, [musicInstance, playlist]);

  const handlePlaySong = async (index: number) => {
    if (!musicInstance) return;

    await musicInstance.setQueue({
      playlist: playlist.id,
      startWith: index,
    });
    await musicInstance.play();
  };

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right duration-300">
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex flex-col items-center mb-6">
          {playlist.attributes.artwork && (
            <img
              src={playlist.attributes.artwork.url.replace(
                "{w}x{h}",
                "300x300"
              )}
              className="w-48 h-48 rounded-lg shadow-lg mb-4"
              alt={playlist.attributes.name}
            />
          )}
          <h2 className="text-xl font-bold text-center">
            {playlist.attributes.name}
          </h2>
          {playlist.attributes.description && (
            <p className="text-muted-foreground text-center max-w-md mt-2">
              {playlist.attributes.description.standard}
            </p>
          )}
          <Button
            className="mt-4"
            onClick={() => {
              musicInstance
                .setQueue({ playlist: playlist.id })
                .then(() => musicInstance.play());
            }}
          >
            Play
          </Button>
        </div>

        {loading && <div className="text-center p-4">Loading tracks...</div>}

        <div className="flex flex-col">
          {tracks.map((track: any, index: number) => (
            <SongItem
              key={track.id}
              song={track}
              onClick={() => handlePlaySong(index)}
              isPlaying={
                nowPlaying &&
                (nowPlaying.id === track.id ||
                  nowPlaying.attributes?.playParams?.id ===
                    track.attributes?.playParams?.id)
              }
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default PlaylistDetailView;
