import Item from "./Item";

interface Album {
  id: string;
  type: string;
  href: string;
  attributes: {
    artistName: string;
    artwork: {
      height: number;
      url: string;
      width: number;
    };
    dateAdded: string;
    genreNames: string[];
    name: string;
    playParams: {
      id: string;
      isLibrary: boolean;
      kind: string;
    };
    releaseDate: string;
    trackCount: number;
  };
}

interface AlbumItemProps {
  album: Album;
  onClick?: () => void;
}

function AlbumItem({ album, onClick }: AlbumItemProps) {
  return (
    <>
      <Item
        title={album.attributes.name}
        subtitle={album.attributes.artistName}
        artworkUrl={album.attributes.artwork.url.replace("{w}x{h}", "128x128")}
        onClick={onClick}
      ></Item>
    </>
  );
}

export default AlbumItem;
