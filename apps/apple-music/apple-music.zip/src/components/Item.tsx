interface Item {
  title: string;
  subtitle?: string;
  artworkUrl?: string;
  durationInMillis?: number;
  onClick?: () => void;
  hideArtwork?: boolean;
  isPlaying?: boolean;
}

function Item({
  title,
  subtitle,
  artworkUrl,
  durationInMillis,
  onClick,
  hideArtwork,
  isPlaying,
}: Item) {
  return (
    <>
      <div className="item" onClick={onClick}>
        <div className="itemContent">
          {!hideArtwork &&
            (artworkUrl ? (
              <img
                src={artworkUrl}
                alt={`Image cover for ${title} playlist`}
                className="itemImage"
              />
            ) : (
              <div className="itemImage"></div>
            ))}
          <div className="itemLabel">
            <span
              className={`itemName overflow-hidden text-ellipsis ${
                isPlaying ? "text-primary" : ""
              }`}
            >
              {title}
            </span>
            {subtitle && <span className="itemSub">{subtitle}</span>}
          </div>
        </div>
        <div>
          {isPlaying ? (
            <div className="visualizer">
              <div className="bar"></div>
              <div className="bar"></div>
              <div className="bar"></div>
            </div>
          ) : (
            <span className="font-light">
              {durationInMillis &&
                Math.floor(durationInMillis / 60000) +
                  ":" +
                  String(
                    Math.floor((durationInMillis % 60000) / 1000)
                  ).padStart(2, "0")}
            </span>
          )}
        </div>
      </div>
    </>
  );
}

export default Item;
