import Item from "./Item";

interface Song {
  id: string;
  type: string;
  href: string;
  attributes: {
    albumName: string;
    artistName: string;
    artwork?: {
      height: number;
      url: string;
      width: number;
    };
    discNumber: number;
    durationInMillis: number;
    genreNames: string[];
    hasLyrics: boolean;
    name: string;
    playParams: {
      catalogId: string;
      id: string;
      isLibrary: boolean;
      kind: string;
      reporting: boolean;
      reportingId: string;
    };
    releaseDate: string;
    trackNuber: number;
  };
}

interface SongItemProps {
  song: Song;
  onClick?: () => void;
  isPlaying?: boolean;
}

function SongItem({ song, onClick, isPlaying }: SongItemProps) {
  const artworkUrl = song.attributes.artwork?.url?.replace(
    "{w}x{h}",
    "128x128"
  );

  return (
    <>
      <Item
        title={song.attributes.name}
        subtitle={`${song.attributes.artistName} | ${song.attributes.albumName}`}
        artworkUrl={artworkUrl}
        durationInMillis={song.attributes.durationInMillis}
        onClick={onClick}
        isPlaying={isPlaying}
      ></Item>
    </>
  );
}

export default SongItem;
