interface PlayerProps {
  nowPlaying: {
    title: string;
    artistName: string;
    artwork: {
      url: string;
      width: number;
      height: number;
    };
    albumName: string;
  };
  mobileMode?: boolean;
  isPlaying: boolean;
  musicInstance: any;
}
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Play, Pause, SkipBack, SkipForward } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { useState, useEffect } from "react";

function Player({
  nowPlaying,
  mobileMode,
  isPlaying,
  musicInstance,
}: PlayerProps) {
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const player = musicInstance?.player ?? musicInstance;

  useEffect(() => {
    if (!player) return;

    const updateTime = () => {
      setCurrentTime(player.currentPlaybackTime);
      setDuration(player.currentPlaybackDuration);
    };

    player.addEventListener("playbackTimeDidChange", updateTime);
    player.addEventListener("playbackDurationDidChange", updateTime);

    // Initial values
    updateTime();

    return () => {
      player.removeEventListener("playbackTimeDidChange", updateTime);
      player.removeEventListener("playbackDurationDidChange", updateTime);
    };
  }, [player]);

  const handlePlayPause = () => {
    if (!player) return;
    if (isPlaying) {
      player.pause();
    } else {
      player.play();
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!player) return;
    const time = parseFloat(e.target.value);
    player.seekToTime(time);
    setCurrentTime(time);
  };

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const Controls = () => (
    <div className="flex flex-col w-full gap-2">
      <div className="flex items-center gap-2 text-xs text-muted-foreground w-full">
        <span>{formatTime(currentTime)}</span>
        <input
          type="range"
          min={0}
          max={duration || 0}
          value={currentTime}
          onChange={handleSeek}
          className="flex-1 h-1 bg-secondary rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary"
        />
        <span>{formatTime(duration)}</span>
      </div>
      <div className="flex items-center justify-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          className="h-12 w-12"
          onClick={() => player?.skipToPreviousItem()}
        >
          <SkipBack className="h-9 w-9" fill="currentColor" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="h-16 w-16 rounded-full"
          onClick={handlePlayPause}
        >
          {isPlaying ? (
            <Pause className="h-9 w-9" fill="currentColor" />
          ) : (
            <Play className="h-9 w-9 ml-1" fill="currentColor" />
          )}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-12 w-12"
          onClick={() => player?.skipToNextItem()}
        >
          <SkipForward className="h-9 w-9" fill="currentColor" />
        </Button>
      </div>
    </div>
  );

  if (mobileMode) {
    return (
      <>
        <Card className="player-sm" onClick={() => setDrawerOpen(true)}>
          <CardContent className="player-sm-content">
            <img
              src={nowPlaying.artwork.url.replace(
                "{w}x{h}",
                `${nowPlaying.artwork.width}x${nowPlaying.artwork.height}`
              )}
              alt={`Album artwork for ${nowPlaying.title} by ${nowPlaying.artistName}`}
            />
          </CardContent>
          <CardHeader className="player-sm-header">
            <CardTitle>{nowPlaying.title}</CardTitle>
            <CardDescription>{nowPlaying.artistName}</CardDescription>
          </CardHeader>
        </Card>
        <Drawer open={drawerOpen} onOpenChange={setDrawerOpen}>
          <DrawerContent className="drawer">
            <div className="drawer-inner">
              <img
                src={nowPlaying.artwork.url.replace(
                  "{w}x{h}",
                  `${nowPlaying.artwork.width}x${nowPlaying.artwork.height}`
                )}
                alt={`Album artwork for ${nowPlaying.title} by ${nowPlaying.artistName}`}
                className="drawerImage"
              />

              <DrawerHeader>
                <DrawerTitle className="text-left text-xl">
                  {nowPlaying.title}
                </DrawerTitle>
                <DrawerDescription className="text-left text-lg">
                  {nowPlaying.artistName}
                </DrawerDescription>
              </DrawerHeader>

              <DrawerFooter>
                <Controls />
              </DrawerFooter>
            </div>
          </DrawerContent>
        </Drawer>
      </>
    );
  }

  return (
    <Card className="player">
      <CardContent>
        <img
          src={nowPlaying.artwork.url.replace(
            "{w}x{h}",
            `${nowPlaying.artwork.width}x${nowPlaying.artwork.height}`
          )}
          alt={`Album artwork for ${nowPlaying.title} by ${nowPlaying.artistName}`}
        />
      </CardContent>
      <div className="playerControls">
        <CardHeader>
          <CardTitle>{nowPlaying.title}</CardTitle>
          <CardDescription>{nowPlaying.artistName}</CardDescription>
        </CardHeader>
        <CardFooter>
          <Controls />
        </CardFooter>
      </div>
    </Card>
  );
}

export default Player;
