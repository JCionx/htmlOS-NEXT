import SongItem from "./SongItem";
import { Pagination } from "./ui/pagination";

interface SongViewProps {
  musicKitLoaded: boolean;
  loadingSongs: boolean;
  songs: any[];
  playSong: (id: string) => void;
  page: number;
  setPage: (page: number) => void;
  nowPlaying?: any;
}

function SongView({
  musicKitLoaded,
  loadingSongs,
  songs,
  playSong,
  page,
  setPage,
  nowPlaying,
}: SongViewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* only show playlists mapping after MusicKit is initialized */}
      {!musicKitLoaded && (
        <div className="p-4 text-center">Waiting for MusicKit...</div>
      )}
      {musicKitLoaded && loadingSongs && (
        <div className="p-4 text-center">Loading songs...</div>
      )}
      {musicKitLoaded && songs && (
        <>
          <div className="flex-1 overflow-y-auto">
            {songs.map((pl: any) => (
              <SongItem
                key={pl.id}
                song={pl}
                onClick={() => playSong(pl.id)}
                isPlaying={
                  nowPlaying &&
                  (nowPlaying.id === pl.id ||
                    nowPlaying.attributes?.playParams?.id ===
                      pl.attributes?.playParams?.id)
                }
              />
            ))}
          </div>
          <Pagination
            currentPage={page / 50}
            onPageChange={(newPage) => setPage(newPage * 50)}
            hasNextPage={songs.length === 50}
            className="mt-auto border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
          />
        </>
      )}
    </div>
  );
}

export default SongView;
