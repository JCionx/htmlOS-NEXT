import Item from "./Item";

interface Artist {
  id: string;
  type: string;
  href: string;
  attributes: {
    name: string;
  };
}

interface ArtistItemProps {
  artist: Artist;
  onClick?: () => void;
}

function ArtistItem({ artist, onClick }: ArtistItemProps) {
  return (
    <>
      <Item
        title={artist.attributes.name}
        onClick={onClick}
        hideArtwork={true}
      ></Item>
    </>
  );
}

export default ArtistItem;
