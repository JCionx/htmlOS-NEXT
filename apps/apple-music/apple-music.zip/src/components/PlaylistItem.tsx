import Item from "./Item";

interface Playlist {
  id: string;
  type: string;
  href: string;
  attributes: {
    artwork: {
      height: number;
      url: string;
      width: number;
    };
    canEdit: boolean;
    dateAdded: string;
    description: {
      standard: string;
    };
    hasCatalog: boolean;
    isPublic: boolean;
    lastModifiedDate: string;
    name: string;
    playParams: {
      id: string;
      isLibrary: boolean;
      kind: string;
    };
  };
}

interface PlaylistItemProps {
  playlist: Playlist;
  onClick?: () => void;
}

function PlaylistItem({ playlist, onClick }: PlaylistItemProps) {
  return (
    <>
      <Item
        title={playlist.attributes.name}
        artworkUrl={playlist.attributes.artwork.url}
        onClick={onClick}
      ></Item>
    </>
  );
}

export default PlaylistItem;
