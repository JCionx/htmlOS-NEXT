import { useEffect, useState } from "react";
import SongItem from "./SongItem";
import { Button } from "./ui/button";

interface AlbumDetailViewProps {
  album: any;
  musicInstance: any;
  playSong?: (id: string) => void;
  nowPlaying?: any;
}

function AlbumDetailView({
  album,
  musicInstance,
  nowPlaying,
}: AlbumDetailViewProps) {
  const [tracks, setTracks] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!musicInstance || !album) return;

    const fetchTracks = async () => {
      setLoading(true);
      try {
        const res = await musicInstance.api.music(
          `v1/me/library/albums/${album.id}/tracks`
        );
        setTracks(res.data.data || []);
      } catch (e) {
        console.error("Failed to fetch album tracks", e);
      } finally {
        setLoading(false);
      }
    };

    fetchTracks();
  }, [musicInstance, album]);

  const handlePlaySong = async (index: number) => {
    if (!musicInstance) return;

    await musicInstance.setQueue({
      album: album.id,
      startWith: index,
    });
    await musicInstance.play();
  };

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right duration-300">
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex flex-col items-center mb-6">
          {album.attributes.artwork && (
            <img
              src={album.attributes.artwork.url.replace("{w}x{h}", "300x300")}
              className="w-48 h-48 rounded-lg shadow-lg mb-4"
              alt={album.attributes.name}
            />
          )}
          <h2 className="text-xl font-bold text-center">
            {album.attributes.name}
          </h2>
          <p className="text-muted-foreground text-center">
            {album.attributes.artistName}
          </p>
          <Button
            className="mt-4"
            onClick={() => {
              musicInstance
                .setQueue({ album: album.id })
                .then(() => musicInstance.play());
            }}
          >
            Play
          </Button>
        </div>

        {loading && <div className="text-center p-4">Loading tracks...</div>}

        <div className="flex flex-col">
          {tracks.map((track: any, index: number) => (
            <SongItem
              key={track.id}
              song={track}
              onClick={() => handlePlaySong(index)}
              isPlaying={
                nowPlaying &&
                (nowPlaying.id === track.id ||
                  nowPlaying.attributes?.playParams?.id ===
                    track.attributes?.playParams?.id)
              }
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default AlbumDetailView;
