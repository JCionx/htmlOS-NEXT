import { useEffect, useState } from "react";
import AlbumItem from "./AlbumItem";
import { Button } from "./ui/button";

interface ArtistDetailViewProps {
  artist: any;
  musicInstance: any;
  onAlbumClick: (album: any) => void;
}

function ArtistDetailView({
  artist,
  musicInstance,
  onAlbumClick,
}: ArtistDetailViewProps) {
  const [albums, setAlbums] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!musicInstance || !artist) return;

    const fetchAlbums = async () => {
      setLoading(true);
      try {
        const res = await musicInstance.api.music(
          `v1/me/library/artists/${artist.id}/albums`
        );
        setAlbums(res.data.data || []);
      } catch (e) {
        console.error("Failed to fetch artist albums", e);
      } finally {
        setLoading(false);
      }
    };

    fetchAlbums();
  }, [musicInstance, artist]);

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right duration-300">
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex flex-col items-center mb-6">
          <h2 className="text-xl font-bold text-center">
            {artist.attributes.name}
          </h2>
          <Button
            className="mt-4"
            onClick={() => {
              musicInstance
                .setQueue({ artist: artist.id })
                .then(() => musicInstance.play());
            }}
          >
            Play Artist
          </Button>
        </div>

        {loading && <div className="text-center p-4">Loading albums...</div>}

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {albums.map((album: any) => (
            <AlbumItem
              key={album.id}
              album={album}
              onClick={() => onAlbumClick(album)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default ArtistDetailView;
