interface HeaderProps {
  title: string;
  onBack?: () => void;
}

function Header({ title, onBack }: HeaderProps) {
  return (
    <>
      <header className="header">
        {onBack && (
          <button className="backButton text-lg text-rose-500" onClick={onBack}>
            ← Back
          </button>
        )}
        <h1 className="headerTitle text-lg font-semibold absolute inset-x-0 text-center pointer-events-none">
          {title}
        </h1>
      </header>
    </>
  );
}

export default Header;
