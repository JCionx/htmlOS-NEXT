import PlaylistItem from "./PlaylistItem";
import { Pagination } from "./ui/pagination";

interface PlaylistViewProps {
  musicKitLoaded: boolean;
  loadingPlaylists: boolean;
  playlists: any[];
  onPlaylistClick: (playlist: any) => void;
  page: number;
  setPage: (page: number) => void;
}

function PlaylistView({
  musicKitLoaded,
  loadingPlaylists,
  playlists,
  onPlaylistClick,
  page,
  setPage,
}: PlaylistViewProps) {
  return (
    <div className="flex flex-col h-full">
      {/* only show playlists mapping after MusicKit is initialized */}
      {!musicKitLoaded && (
        <div className="p-4 text-center">Waiting for MusicKit...</div>
      )}
      {musicKitLoaded && loadingPlaylists && (
        <div className="p-4 text-center">Loading playlists...</div>
      )}
      {musicKitLoaded && playlists && (
        <>
          <div className="flex-1 overflow-y-auto">
            {playlists.map((pl: any) => (
              <PlaylistItem
                key={pl.id}
                playlist={pl}
                onClick={() => onPlaylistClick(pl)}
              />
            ))}
          </div>
          <Pagination
            currentPage={page / 50}
            onPageChange={(newPage) => setPage(newPage * 50)}
            hasNextPage={playlists.length === 50}
            className="mt-auto border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
          />
        </>
      )}
    </div>
  );
}

export default PlaylistView;
