import React, { useState, useEffect, useRef } from "react";
import PlaylistView from "./components/PlaylistView";
import ArtistView from "./components/ArtistView";
import AlbumView from "./components/AlbumView";
import SongView from "./components/SongView";
import PlaylistDetailView from "./components/PlaylistDetailView";
import ArtistDetailView from "./components/ArtistDetailView";
import AlbumDetailView from "./components/AlbumDetailView";
import Player from "./components/Player";
import Header from "./components/Header";
import { Button } from "./components/ui/button";

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any, info: any) {
    console.error("Unhandled error in subtree:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return <div>Something went wrong. Try reloading the page.</div>;
    }
    return this.props.children;
  }
}

function App() {
  const musicRef = useRef<any>(null);
  const [musicKitLoaded, setMusicKitLoaded] = useState(false);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [playlists, setPlaylists] = useState<any[] | null>(null);
  const [artists, setArtists] = useState<any[] | null>(null);
  const [albums, setAlbums] = useState<any[] | null>(null);
  const [songs, setSongs] = useState<any[] | null>(null);
  const [loadingPlaylists, setLoadingPlaylists] = useState(false);
  const [loadingArtists, setLoadingArtists] = useState(false);
  const [loadingAlbums, setLoadingAlbums] = useState(false);
  const [loadingSongs, setLoadingSongs] = useState(false);
  const [nowPlaying, setNowPlaying] = useState<any>(null);

  const [songsPage, setSongsPage] = useState(0);
  const [playlistsPage, setPlaylistsPage] = useState(0);
  const [artistsPage, setArtistsPage] = useState(0);
  const [albumsPage, setAlbumsPage] = useState(0);

  const [currentView, setCurrentView] = useState<
    | "none"
    | "playlists"
    | "artists"
    | "albums"
    | "songs"
    | "playlist-detail"
    | "artist-detail"
    | "album-detail"
  >("none");
  const [history, setHistory] = useState<string[]>([]);
  const [mobileMode, setMobileMode] = useState(false);

  const [selectedPlaylist, setSelectedPlaylist] = useState<any>(null);
  const [selectedArtist, setSelectedArtist] = useState<any>(null);
  const [selectedAlbum, setSelectedAlbum] = useState<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const navigateTo = (view: typeof currentView) => {
    setHistory((prev) => [...prev, currentView]);
    setCurrentView(view);
  };

  const goBack = () => {
    setHistory((prev) => {
      const newHistory = [...prev];
      const lastView = newHistory.pop();
      if (lastView) {
        setCurrentView(lastView as any);
      }
      return newHistory;
    });
  };

  const getHeaderTitle = () => {
    switch (currentView) {
      case "none":
        return "Library";
      case "playlists":
        return "Playlists";
      case "artists":
        return "Artists";
      case "albums":
        return "Albums";
      case "songs":
        return "Songs";
      case "playlist-detail":
        return selectedPlaylist?.attributes.name || "Playlist";
      case "artist-detail":
        return selectedArtist?.attributes.name || "Artist";
      case "album-detail":
        return selectedAlbum?.attributes.name || "Album";
      default:
        return "Library";
    }
  };

  async function loadLocalStorage() {
    const url = await (window as any).loadInternalFile("localStorage.json");
    if (url) {
      try {
        const response = await fetch(url);
        if (response.ok) {
          const items = await response.json();
          for (const key in items) {
            localStorage.setItem(key, items[key]);
          }
        } else {
          console.error(
            "Failed to fetch localStorage.json:",
            response.statusText
          );
        }
      } catch (err) {
        console.error("Failed to load or parse localStorage data:", err);
      }
    }
  }

  async function saveLocalStorage() {
    // get all locaStorage keys
    const allItems: { [key: string]: string } = {};

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        allItems[key] = localStorage.getItem(key) || "";
      }
    }

    await (window as any).saveInternalFile(
      "localStorage.json",
      JSON.stringify(allItems)
    );

    return;
  }

  const handleLogin = async () => {
    if (!musicRef.current) {
      console.error("MusicKit not initialized");
      return;
    }

    try {
      await musicRef.current.authorize();
      setIsAuthorized(true);
      await saveLocalStorage();
    } catch (err) {
      console.error("Failed to authorize MusicKit:", err);
    }
  };

  const handleLogout = async () => {
    if (!musicRef.current) return;
    try {
      await musicRef.current.unauthorize();
      setIsAuthorized(false);
      setPlaylists(null);
      setArtists(null);
      setAlbums(null);
      setSongs(null);
      setCurrentView("none");
    } catch (err) {
      console.error("Failed to unauthorize:", err);
    }
  };

  useEffect(() => {
    const checkMobileMode = () => {
      setMobileMode(window.matchMedia("(max-width: 768px)").matches);
    };

    // Initial check
    checkMobileMode();

    // Add event listener for window resize
    window.addEventListener("resize", checkMobileMode);

    // Cleanup event listener on unmount
    return () => {
      window.removeEventListener("resize", checkMobileMode);
    };
  }, []);

  useEffect(() => {
    let mounted = true;

    const initMusicKit = async () => {
      try {
        await loadLocalStorage();
        // If an instance already exists, use it (avoids re-configure)
        const existing =
          (window as any).MusicKit?.getInstance &&
          (window as any).MusicKit.getInstance();
        if (existing) {
          musicRef.current = existing;
          if (mounted) {
            setMusicKitLoaded(true);
            if (existing.isAuthorized) setIsAuthorized(true);
          }
          return;
        }

        // Configure (will be a no-op if already configured by the platform)
        await (window as any).MusicKit.configure({
          developerToken:
            "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlI3UUdLVUJQS1AifQ.eyJpYXQiOjE3NTU5MzE2MjgsImV4cCI6MTc3MTQ4MzYyOCwiaXNzIjoiRzZIM0NLV005QyJ9.dI0jzSFdat6ybfoUEqLLwLxI_4X60622o03lhrD-CfeXrOY-19oyffH0bVTfCUeRCeP9z7cI1AsvVqxtgRkx0w",
          app: {
            name: "My Music App",
            build: "1978.4.1",
          },
          bitrate: (window as any).MusicKit.PlaybackBitrate.HIGH,
        });

        musicRef.current = (window as any).MusicKit.getInstance();

        if (mounted) {
          setMusicKitLoaded(true);
          if (musicRef.current.isAuthorized) setIsAuthorized(true);
        }
      } catch (err) {
        console.error("Error initializing MusicKit:", err);
      }
    };

    // single handler reference so we can remove it later
    const handler = () => {
      initMusicKit();
    };

    // Listen on both document and window (some environments dispatch on one or the other)
    document.addEventListener("musickitloaded", handler);
    window.addEventListener("musickitloaded", handler);

    // If the script already loaded before this effect ran, MusicKit will be present on window.
    // Call init immediately to avoid missing the event.
    if ((window as any).MusicKit) {
      handler();
    }

    return () => {
      mounted = false;
      document.removeEventListener("musickitloaded", handler);
      window.removeEventListener("musickitloaded", handler);
    };
  }, []);

  useEffect(() => {
    if (!musicKitLoaded || !musicRef.current || !isAuthorized) return;

    let cancelled = false;
    const load = async () => {
      try {
        setLoadingPlaylists(true);
        const res = await musicRef.current.api.music(
          "v1/me/library/playlists",
          {
            limit: 50,
            offset: playlistsPage,
          }
        );
        if (!cancelled) setPlaylists(res.data.data || []);
      } catch (err) {
        console.error("Failed to load playlists:", err);
        if (!cancelled) setPlaylists([]);
      } finally {
        if (!cancelled) setLoadingPlaylists(false);
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [musicKitLoaded, isAuthorized, playlistsPage]);

  useEffect(() => {
    if (!musicKitLoaded || !musicRef.current || !isAuthorized) return;

    let cancelled = false;
    const load = async () => {
      try {
        setLoadingArtists(true);
        const res = await musicRef.current.api.music("v1/me/library/artists", {
          limit: 50,
          offset: artistsPage,
        });
        if (!cancelled) setArtists(res.data.data || []);
      } catch (err) {
        console.error("Failed to load artists:", err);
        if (!cancelled) setArtists([]);
      } finally {
        if (!cancelled) setLoadingArtists(false);
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [musicKitLoaded, isAuthorized, artistsPage]);

  useEffect(() => {
    if (!musicKitLoaded || !musicRef.current || !isAuthorized) return;

    let cancelled = false;
    const load = async () => {
      try {
        setLoadingAlbums(true);
        const res = await musicRef.current.api.music("v1/me/library/albums", {
          limit: 50,
          offset: albumsPage,
        });
        if (!cancelled) setAlbums(res.data.data || []);
      } catch (err) {
        console.error("Failed to load albums:", err);
        if (!cancelled) setAlbums([]);
      } finally {
        if (!cancelled) setLoadingAlbums(false);
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [musicKitLoaded, isAuthorized, albumsPage]);

  // new effect: fetch songs when musicKitLoaded or songsPage (offset) changes
  useEffect(() => {
    if (!musicKitLoaded || !musicRef.current || !isAuthorized) return;

    let cancelled = false;
    const loadSongs = async () => {
      try {
        setLoadingSongs(true);
        const res = await musicRef.current.api.music("v1/me/library/songs", {
          limit: 50,
          offset: songsPage,
        });
        if (!cancelled) setSongs(res.data.data || []);
      } catch (err) {
        console.error("Failed to load songs:", err);
        if (!cancelled) setSongs([]);
      } finally {
        if (!cancelled) setLoadingSongs(false);
      }
    };

    loadSongs();

    return () => {
      cancelled = true;
    };
  }, [musicKitLoaded, songsPage, isAuthorized]);

  useEffect(() => {
    if (!musicKitLoaded || !musicRef.current) return;

    // choose the correct event target (player or root instance)
    const target: any = musicRef.current.player ?? musicRef.current;
    if (!target) return;

    // Sync initial nowPlaying safely
    try {
      const initial = target.nowPlayingItem ?? null;
      if (initial) setNowPlaying(initial);
      setIsPlaying(target.isPlaying);
    } catch (e) {
      console.warn("Unable to read nowPlayingItem initially:", e);
    }

    // stable handlers for add/remove
    const onNowPlayingChange = () => {
      try {
        setNowPlaying(target.nowPlayingItem ?? null);
      } catch (e) {
        setNowPlaying(null);
      }
    };

    const onPlaybackStateChange = () => {
      try {
        setNowPlaying(target.nowPlayingItem ?? null);
        setIsPlaying(target.isPlaying);
      } catch (e) {
        setNowPlaying(null);
        setIsPlaying(false);
      }
    };

    const canAdd = typeof target.addEventListener === "function";
    if (canAdd) {
      try {
        target.addEventListener("nowPlayingItemDidChange", onNowPlayingChange);
        target.addEventListener(
          "playbackStateDidChange",
          onPlaybackStateChange
        );
      } catch (err) {
        console.warn("Failed to attach MusicKit listeners:", err);
      }
    } else {
      console.warn("MusicKit target has no addEventListener:", target);
    }

    return () => {
      try {
        if (canAdd) {
          target.removeEventListener(
            "nowPlayingItemDidChange",
            onNowPlayingChange
          );
          target.removeEventListener(
            "playbackStateDidChange",
            onPlaybackStateChange
          );
        }
      } catch (e) {
        // ignore cleanup errors
      }
    };
  }, [musicKitLoaded]);

  const playSong = async (id: string) => {
    if (!musicRef.current) {
      console.error("MusicKit not initialized");
      return;
    }

    await musicRef.current.authorize();
    await musicRef.current.setQueue({ song: id });
    await musicRef.current.play();
  };

  const openPlaylist = (playlist: any) => {
    setSelectedPlaylist(playlist);
    navigateTo("playlist-detail");
  };

  const openArtist = (artist: any) => {
    setSelectedArtist(artist);
    navigateTo("artist-detail");
  };

  const openAlbum = (album: any) => {
    setSelectedAlbum(album);
    navigateTo("album-detail");
  };

  return (
    <ErrorBoundary>
      {currentView === "none" ? (
        <Header title="Library" />
      ) : (
        <Header
          title={getHeaderTitle()}
          onBack={history.length > 0 ? () => goBack() : undefined}
        />
      )}
      <div className="mainContainer">
        <div className="content">
          {currentView === "none" && (
            <div className="list animate-in slide-in-from-left duration-300">
              <div className="item" onClick={() => navigateTo("playlists")}>
                <span className="itemName">Playlists</span>
              </div>
              <div className="item" onClick={() => navigateTo("artists")}>
                <span className="itemName">Artists</span>
              </div>
              <div className="item" onClick={() => navigateTo("albums")}>
                <span className="itemName">Albums</span>
              </div>
              <div className="item" onClick={() => navigateTo("songs")}>
                <span className="itemName">Songs</span>
              </div>

              {!isAuthorized ? (
                <div className="p-4 flex justify-center">
                  <Button
                    onClick={() => handleLogin()}
                    className="w-full max-w-xs"
                  >
                    Login with Apple Music
                  </Button>
                </div>
              ) : (
                <div className="p-4 flex justify-center">
                  <Button
                    variant="destructive"
                    onClick={() => handleLogout()}
                    className="w-full max-w-xs"
                  >
                    Log Out
                  </Button>
                </div>
              )}
            </div>
          )}

          {currentView === "playlists" && (
            <div className="animate-in slide-in-from-right duration-300 h-full">
              <PlaylistView
                musicKitLoaded={musicKitLoaded}
                loadingPlaylists={loadingPlaylists}
                playlists={playlists || []}
                onPlaylistClick={openPlaylist}
                page={playlistsPage}
                setPage={setPlaylistsPage}
              />
            </div>
          )}

          {currentView === "artists" && (
            <div className="animate-in slide-in-from-right duration-300 h-full">
              <ArtistView
                musicKitLoaded={musicKitLoaded}
                loadingArtists={loadingArtists}
                artists={artists || []}
                onArtistClick={openArtist}
                page={artistsPage}
                setPage={setArtistsPage}
              />
            </div>
          )}

          {currentView === "albums" && (
            <div className="animate-in slide-in-from-right duration-300 h-full">
              <AlbumView
                musicKitLoaded={musicKitLoaded}
                loadingAlbums={loadingAlbums}
                albums={albums || []}
                onAlbumClick={openAlbum}
                page={albumsPage}
                setPage={setAlbumsPage}
              />
            </div>
          )}

          {currentView === "songs" && (
            <div className="animate-in slide-in-from-right duration-300 h-full">
              <SongView
                musicKitLoaded={musicKitLoaded}
                loadingSongs={loadingSongs}
                songs={songs || []}
                playSong={playSong}
                page={songsPage}
                setPage={setSongsPage}
                nowPlaying={nowPlaying}
              />
            </div>
          )}

          {currentView === "playlist-detail" && selectedPlaylist && (
            <PlaylistDetailView
              playlist={selectedPlaylist}
              musicInstance={musicRef.current}
              playSong={playSong}
              nowPlaying={nowPlaying}
            />
          )}

          {currentView === "artist-detail" && selectedArtist && (
            <ArtistDetailView
              artist={selectedArtist}
              musicInstance={musicRef.current}
              onAlbumClick={openAlbum}
            />
          )}

          {currentView === "album-detail" && selectedAlbum && (
            <AlbumDetailView
              album={selectedAlbum}
              musicInstance={musicRef.current}
              playSong={playSong}
              nowPlaying={nowPlaying}
            />
          )}
        </div>

        {nowPlaying && (
          <Player
            nowPlaying={nowPlaying}
            mobileMode={mobileMode}
            isPlaying={isPlaying}
            musicInstance={musicRef.current}
          />
        )}
      </div>
    </ErrorBoundary>
  );
}

export default App;
